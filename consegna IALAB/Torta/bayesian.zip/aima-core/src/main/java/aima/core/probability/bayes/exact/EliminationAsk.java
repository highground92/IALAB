package aima.core.probability.bayes.exact;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;
import aima.core.probability.CategoricalDistribution;
import aima.core.probability.Factor;
import aima.core.probability.RandomVariable;
import aima.core.probability.bayes.*;
import aima.core.probability.proposition.AssignmentProposition;
import aima.core.probability.util.ProbabilityTable;

public class EliminationAsk implements BayesInference {

	public static List<Node> irrelevantList = new ArrayList<>();

    /**
     * Applica l'algoritmo di variable elimination
     * @param bn rete bayesiana
     * @param query array contenente le query
     * @param assig array contenente le evidence
     * @param heuristic euristica di ordinamento scelta
     * @return fattore contenente la distribuzione di probabilità relativa alla/e query
     */
    public static Factor eliminationVariable(aima.core.probability.bayes.BayesianNetwork bn, RandomVariable[] query, AssignmentProposition[] assig, int heuristic){
        List<RandomVariable> bnVars = bn.getVariablesInTopologicalOrder();
        //viene applicato il primo teorema per riconoscere e eliminare le irrelevant variables
        Set<RandomVariable> hidden = EliminationAsk.findHiddenVariables(query, assig, bn, bnVars);

        //varElim contiene la lista ordinata di random variables
        List<RandomVariable> varElim = EliminationAsk.orderingRandomVariables(query, assig, bn, bnVars ,heuristic);

        List<RandomVariable> remainingVars = new ArrayList<RandomVariable>(varElim);
        Graph graph = new Graph(bn,remainingVars);
        //trasformiamo da array a Set
        Set<Node> tempSetRv = new HashSet<>();
        for (int k=0;k<query.length;k++){
            tempSetRv.add(bn.getNode(query[k]));
        }
        Set<AssignmentProposition> tempSetE = new HashSet<>();
        for (int j=0;j<assig.length;j++){
            tempSetE.add(assig[j]);
        }
        //Viene applicato il secondo teorema per eliminare le variabili m-separated dalla query tramite evidence
        List<Node> tempList = graph.getNotMSeparatedGraph(tempSetRv,tempSetE);

        System.out.println("Dopo applicazione m-separated");
        for(Node n : tempList){
            System.out.println(n.getRandomVariable().getName());
        }

        //si trasforma la lista di nodi in una lista di random variables
        List<RandomVariable> tempListRv = new ArrayList<>();
        for(Node z : tempList){
            tempListRv.add(z.getRandomVariable());
        }

        //si creano i fattori delle random variables
        List<Factor> factors = new ArrayList<Factor>();
        for(RandomVariable rv : tempListRv){
            factors.add(0, EliminationAsk.makeFactor(rv, assig, bn));
        }

        factors = EliminationAsk.sumOutVar(tempListRv,factors,hidden);

        System.out.println("----------------------------");

        Factor product = EliminationAsk.pointwiseProduct(factors);
        return product;
    }

    /**
     * Sequenza di operazioni per calcolare il Most Probable Explanation
     * @param X array contenente le query
     * @param e array contenente le evidence
     * @param bn rete bayesiana
     * @param hidden set contenente le hidden variables
     * @param graph grafo
     * @param heuristic euristica di ordinamento scelta
     * @return la cpt relativa alla rete
     */
	public static CategoricalDistribution eliminationAskMPE(final RandomVariable[] X,
														 final AssignmentProposition[] e, final BayesianNetwork bn,
														 Set<RandomVariable> hidden, Graph graph, int heuristic){
		List<Factor> factors = new ArrayList<Factor>();
		GreedyOrdering go = new GreedyOrdering();
		List<RandomVariable> order = go.greedyOrdering(heuristic,graph.getGraph(),bn);

		for(RandomVariable var : order){
			factors.add(0, makeFactor(var, e, bn));
		}

		factors = sumOutVarMPE(order,factors,hidden);

		System.out.println("----------------------------");

		Factor product = pointwiseProduct(factors).maxOut(X);

		//printResult();

		return (ProbabilityTable) product;
	}

	/**
	 * Sequenza di operazioni per calcolare la Maximum a Posteriori Hypotesis
	 * @param X array contenente le query
	 * @param e array contenente le evidence
	 * @param bn rete bayesiana
	 * @param hidden set contenente le hidden variables
	 * @param graph grafo
	 * @param heuristic euristica di ordinamento scelta
	 * @return la cpt relativa alla/e query
	 */
	public CategoricalDistribution eliminationAskMAP(final RandomVariable[] X,
													 final AssignmentProposition[] e, final BayesianNetwork bn,
													 Set<RandomVariable> hidden, Graph graph, int heuristic){
		List<Factor> factors = new ArrayList<Factor>();
		List<RandomVariable> xList = new ArrayList<>();
		for(RandomVariable  rv : X){
			xList.add(rv);
		}

		GreedyOrdering go = new GreedyOrdering();
		List<RandomVariable> order = go.greedyOrdering(heuristic,graph.getGraph(),bn);
		List<RandomVariable> orderedNonMap = new ArrayList<>();
		List<RandomVariable> orderedQuery = new ArrayList<>();
		for(RandomVariable rv : order){
			if (xList.contains(rv))
				orderedQuery.add(rv);
			else
				orderedNonMap.add(rv);
		}
		List<RandomVariable> orderedFinal = new ArrayList<>();
		//le variabili Non-Map vengono messe in testa alla lista
		orderedFinal.addAll(orderedNonMap);
		orderedFinal.addAll(orderedQuery);

		for(RandomVariable var : orderedFinal){
			factors.add(0, makeFactor(var, e, bn));
		}
		//marginalizziamo le variabili Non-Map
		factors = sumOutVar(orderedNonMap,factors,hidden);

		Set<RandomVariable> querySet = new HashSet<>();
		for(RandomVariable rv : orderedQuery){
			querySet.add(rv);
		}
		//massimizziamo le variabili Map (query)
		factors = sumOutVarMPE(orderedQuery,factors,querySet);

		System.out.println("----------------------------");

		Factor product = pointwiseProduct(factors).maxOut(X);

        //printResult();
		return (ProbabilityTable) product;
	}

    /**
     * Effettua il Rollup Filtering su reti bayesiane dinamiche.
     * @param bn rete bayesiana
     * @param n numero di iterazioni che l'utente vuole calcolare
     */
    public static void applyDbnEliminationVariable(BayesianNetwork bn, int n, HashMap<String, List<String>> evidenceDBN) {
        List<RandomVariable> bnVars = bn.getVariablesInTopologicalOrder();
        HashMap<RandomVariable,RandomVariable> transitionMap = new HashMap<>();
        RandomVariable[] query = SupportStructureBN.query;
        //AssignmentProposition[] assig = SupportStructureBN.assig;
        AssignmentProposition[] assig = new AssignmentProposition[SupportStructureBN.assig.length];
        List<String> values;
        Iterator it = evidenceDBN.entrySet().iterator();
        int j=0;
        while (it.hasNext()) {
            Map.Entry entry = (Map.Entry)it.next();
            for(RandomVariable v : bnVars){
                if(v.getName().equals(entry.getKey())){
                    values = evidenceDBN.get(entry.getKey());
                    assig[j] = new AssignmentProposition(v, values.get(0));
                    j++;
                }
            }
        }

        //costruisco la map che collega ogni rv al tempo t+1 con se stessa al tempo t0
        for(RandomVariable rv : bn.getVariablesInTopologicalOrder()){
            if(rv.getName().substring(rv.getName().length()-1).equals("T")){
                RandomVariable tempT = rv;
                for(RandomVariable rv2: bn.getVariablesInTopologicalOrder()){
                    if (rv2.getName().equals(tempT.getName().substring(0,tempT.getName().length()-1))){
                        if(bn.getNode(tempT).getParents().contains(bn.getNode(rv2))) {
                            transitionMap.put(tempT, rv2);
                            //System.out.println("inserisco in map " + tempT.getName() + " -> " + rv2.getName());
                        }
                    }
                }
            }
        }

        System.out.println("Inizio iterazione 1");
        Factor product = EliminationAsk.eliminationVariableDBN(bn, query, assig,null,bnVars);
        System.out.println("RISULTATO 1");
        product = ((ProbabilityTable)product).normalize();
        System.out.println(product.getRandomVarInfo().keySet() + " con valori normalizzati " + product);
        System.out.println("Fine iterazione 1");

        int i = 1;
        while(i < n) {
            System.out.println("Inizio iterazione " + (i+1));
            System.out.println("product randomvarInfo keyset " + product.getRandomVarInfo().keySet());

            for(RandomVariable rv : transitionMap.keySet()){
                if (product.getRandomVarInfo().keySet().contains(rv)) {
                    product.getRandomVarInfo().put(transitionMap.get(rv), product.getRandomVarInfo().get(rv));
                    product.getRandomVarInfo().remove(rv);
                }
            }
            it = evidenceDBN.entrySet().iterator();
            j=0;
            while (it.hasNext()) {
                Map.Entry entry = (Map.Entry)it.next();
                for(RandomVariable v : bnVars){
                    if(v.getName().equals(entry.getKey())){
                        values = evidenceDBN.get(entry.getKey());
                        assig[j] = new AssignmentProposition(v, values.get(i));
                        j++;
                    }
                }
            }
            product = EliminationAsk.eliminationVariableDBN(bn, query, assig, product, bnVars);
            System.out.println("RISULTATO " + (i+1));
            product = ((ProbabilityTable)product).normalize();
            System.out.println(product.getRandomVarInfo().keySet() + " con valori normalizzati " + product);
            System.out.println("Fine iterazione " + (i+1));
            i++;
        }
    }

     /**
     * Analizza le random variables eliminando le irrelevant (utilizzato nell'algoritmo di variable elimination)
     * @param X array contenente le query
     * @param e array contenente le evidence
     * @param bn rete bayesiana
     * @param bnVARS collezione contenente le random variables
     * @return set contenente le hidden variables
     */
	public static Set<RandomVariable> findHiddenVariables(final RandomVariable[] X,
														 final AssignmentProposition[] e, final BayesianNetwork bn, Collection<RandomVariable> bnVARS) {
		Set<RandomVariable> hidden = new HashSet<>();
		hidden.addAll(bnVARS);

		List<RandomVariable> queryList = new ArrayList<>();
		for(RandomVariable rv : X){
		    queryList.add(rv);
        }

        List<RandomVariable> evidenceList = new ArrayList<>();
        for(AssignmentProposition ap : e){
            evidenceList.add(ap.getTermVariable());
        }

		for (RandomVariable x : X) {
			hidden.remove(x);
		}
		for (AssignmentProposition ap : e) {
			hidden.removeAll(ap.getScope());
		}

		System.out.println("Hidden: ");
		for(RandomVariable h : hidden){
			System.out.println(h.getName());
		}
		System.out.println("\nEvidence: ");
		for(AssignmentProposition ass: e){
			System.out.println(ass.getTermVariable().getName());
		}

		List<Node> ancestorsTemp = new ArrayList<>();
		for(RandomVariable rv : X){
			if(bn.getNode(rv).getAncestors()!=null) {
				for (Node n : bn.getNode(rv).getAncestors()) {
					if(!ancestorsTemp.contains(n) && !evidenceList.contains(n.getRandomVariable()) && !queryList.contains(n.getRandomVariable()))
						ancestorsTemp.add(n);
				}
			}
		}
		for(AssignmentProposition ap : e){
			if(bn.getNode(ap.getTermVariable()).getAncestors()!=null) {
				for (Node n : bn.getNode(ap.getTermVariable()).getAncestors()) {
					if(!ancestorsTemp.contains(n) && !evidenceList.contains(n.getRandomVariable()) && !queryList.contains(n.getRandomVariable()))
						ancestorsTemp.add(n);
				}
			}
		}

		for(RandomVariable h : hidden){
			if(!ancestorsTemp.contains(bn.getNode(h))) {
				bnVARS.remove(h);
                System.out.println(h.getName()+" è irrelevant variable ed è rimossa");
				irrelevantList.add(bn.getNode(h));
			}
		}
		return hidden;
	}

    /**
     * Analizza le random variables (utilizzato negli algoritmi MPE, MAP e DBN)
     * @param X array contenente le query
     * @param e array contenente le evidence
     * @param bn rete bayesiana
     * @param bnVARS collezione contenente le random variables
     * @return set contenente le hidden variables
     */
	public static Set<RandomVariable> calculateAllVariables(final RandomVariable[] X,
															final AssignmentProposition[] e, final BayesianNetwork bn, Collection<RandomVariable> bnVARS){
		Set<RandomVariable> hidden = new HashSet<>();
		hidden.addAll(bnVARS);

		for (RandomVariable x : X) {
			hidden.remove(x);
		}
		for (AssignmentProposition ap : e) {
			hidden.removeAll(ap.getScope());
		}

		System.out.println("HIDDEN");
		for(RandomVariable h : hidden){
			System.out.print(h.getName()+" ");
		}
		System.out.println("\nEVIDENCE");
		for(AssignmentProposition ass: e){
			System.out.println(ass.getTermVariable().getName());
		}

		Set<Node> parents = new HashSet<Node>();
		Set<Node> p;
		for(RandomVariable var : bnVARS){
			p = bn.getNode(var).getParents();
			for(Node n : p)
				parents.add(n);
		}
		return hidden;
	}

    /**
     * A differenza di eliminationVariable, non vengono eliminate le irrelevant variables, non vengono eliminati i nodi M-separated
     * e viene aggiunto al calcolo l'eventuale campo input
     * @param bn rete bayesiana
     * @param query array contenente le query
     * @param assig array contenente le evidence
     * @param input fattore ricavato dall'iterazione precedente
     * @param bnVars lista di tutte le random variable
     * @return fattore contenente la distribuzione di probabilità della/e query al tempo attuale
     */
    public static Factor eliminationVariableDBN(aima.core.probability.bayes.BayesianNetwork bn, RandomVariable[] query,
                                                AssignmentProposition[] assig, Factor input, List<RandomVariable> bnVars){
        List<RandomVariable> tempVars = new ArrayList<>();

        for(RandomVariable rv : bnVars){
            tempVars.add(rv);
        }
        //stampa per il controllo del valore della evidence al tempo t
        for(AssignmentProposition prop : assig)
            System.out.println(prop);

        Set<RandomVariable> hidden = EliminationAsk.calculateAllVariables(query, assig, bn, bnVars);

        List<Factor> factors = new ArrayList<Factor>();

        if(input!=null) {
            //System.out.println("INPUT è: " + input.getArgumentVariables());
            factors.add(input);
        }

        for(RandomVariable rv : tempVars){
            factors.add(0, EliminationAsk.makeFactor(rv, assig, bn));
        }

        factors = EliminationAsk.sumOutVar(tempVars,factors,hidden);

        System.out.println("----------------------------");

        Factor product = EliminationAsk.pointwiseProduct(factors);
        return product;
    }

	public static Factor makeFactor(RandomVariable var, AssignmentProposition[] e, BayesianNetwork bn) {
		Node n = bn.getNode(var);
		if (!(n instanceof FiniteNode)) {
			throw new IllegalArgumentException(
					"Elimination-Ask only works with finite Nodes.");
		}
		FiniteNode fn = (FiniteNode) n;
		List<AssignmentProposition> evidence = new ArrayList<AssignmentProposition>();
		for (AssignmentProposition ap : e) {
			if (fn.getCPT().contains(ap.getTermVariable())) {
				evidence.add(ap);
			}
		}
		return fn.getCPT().getFactorFor(
                evidence.toArray(new AssignmentProposition[evidence.size()]));
	}

	public static List<Factor> sumOutVar(List<RandomVariable> order, List<Factor> factors,
								   Set<RandomVariable> hidden){
		for(RandomVariable var : order){
			if(hidden.contains(var)){
				factors = sumOut(var, factors);
			}
		}
		return factors;
	}

	public static List<Factor> sumOutVarMPE(List<RandomVariable> order, List<Factor> factors,
										 Set<RandomVariable> hidden){

		for(RandomVariable var : order){
			if(hidden.contains(var)){
				factors = sumOutMPE(var, factors);
			}
		}
		return factors;
	}

	private static List<Factor> sumOut(RandomVariable var, List<Factor> factors) {
		List<Factor> summedOutFactors = new ArrayList<Factor>();
		List<Factor> toMultiply = new ArrayList<Factor>();
        //System.out.println("Sommo fuori " + var.getName());
        //System.out.println("Lista factor: ");
        //for(Factor fc : factors)
            //System.out.println(" "+fc.getRandomVarInfo().keySet());
		for (Factor f : factors) {
			if (f.contains(var)) {
				//System.out.println("added to toMultiply "+f.getArgumentVariables().toString() + " : " + f);
				toMultiply.add(f);
			} else {
                //System.out.println("added to summedOut "+f.getArgumentVariables().toString() + " : " + f);
				summedOutFactors.add(f);
			}
		}
        //System.out.println("fattori da moltiplicare: ");
		//if(!toMultiply.isEmpty())
		//    for(Factor f : toMultiply)
        //        System.out.println(f.getArgumentVariables());
        if(!toMultiply.isEmpty())
		    summedOutFactors.add(pointwiseProduct(toMultiply).sumOut(var));
        //System.out.println("risultato sumOut di "+var.getName()+": " +summedOutFactors);
		return summedOutFactors;
	}

    /**
     * versione modificata per MPE dove viene calcolato il maxOut invece del sumOut
     * @param var variabile che viene massimizzata
     * @param factors lista di tutti i fattori
     * @return lista dei fattori aggiornata dopo il maxOut
     */
	private static List<Factor> sumOutMPE(RandomVariable var, List<Factor> factors) {
		List<Factor> maxedOutFactors = new ArrayList<Factor>();
		List<Factor> toMultiply = new ArrayList<Factor>();
		//System.out.println("eseguo maxOut per " + var.getName());
		for (Factor f : factors) {
			if (f.contains(var)) {
				toMultiply.add(f);
				//System.out.println("to multiply add " + f);
			} else {
				maxedOutFactors.add(f);
				//System.out.println("maxedoutfactors add " + f);
			}
		}
		maxedOutFactors.add(pointwiseProduct(toMultiply).maxOut(var));
		return maxedOutFactors;
	}

	public static Factor pointwiseProduct(List<Factor> factors) {

		Factor product = factors.get(0);
		for (int i = 1; i < factors.size(); i++) {
			product = product.pointwiseProduct(factors.get(i));
		}

		return product;
	}

    /**
     *
     * @param X array contentente le query
     * @param e array contenente le evidence
     * @param bn rete bayesiana
     * @param vars lista contenente tutte le random variables
     * @param heuristic euristica di ordinamento scelta
     * @return lista di random variables ordinata secondo l'euristica passata
     */
    public static List<RandomVariable> orderingRandomVariables(RandomVariable[] X, AssignmentProposition[] e, BayesianNetwork bn, List<RandomVariable> vars, int heuristic){
        Graph graph = new Graph(bn,vars);
        Set<Node> tempSetRv = new HashSet<>();

        for (int i=0;i<X.length;i++){
            tempSetRv.add(bn.getNode(X[i]));
        }
        Set<AssignmentProposition> tempSetE = new HashSet<>();
        for (int j=0;j<e.length;j++){
            tempSetE.add(e[j]);
        }

        List<Node> tempList = graph.getGraph();
        GreedyOrdering go = new GreedyOrdering();
        return go.greedyOrdering(heuristic,tempList,bn);
    }

    /**
     * Stampa la distribuzione di probabilità di tutte le random variable
     */
	public static void printResult(){
		Iterator iter = ProbabilityTable.totRows.entrySet().iterator();
		while(iter.hasNext()){
			Map.Entry entry = (Map.Entry) iter.next();
			System.out.println("key --> "+entry.getKey()); //è la probabilità
			ArrayList<RandomVariable> var = (ArrayList<RandomVariable>) entry.getValue();
			for(RandomVariable v : var) {
				System.out.print(v.getName()+"("+v.getAssign()+") - "); //valori di verità associati alla cpt
			}
			System.out.println();
		}
	}

    public static HashMap<String,List<String>> parseEvidenceDBN(String path) throws IOException {
        HashMap<String,List<String>> evidenceDBN = new HashMap<>();
        FileReader file = new FileReader(path);
        BufferedReader rete = new BufferedReader(file);

        String delims = "[ ]+";
        String[] split;
        String line = rete.readLine();

        while (line != null) {
			List<String> values = new ArrayList<>();
            split = line.split(delims);
            int i=1;
            while(i<split.length){
                values.add(split[i]);
                i++;
            }
            evidenceDBN.put(split[0],values);
            line = rete.readLine();
        }

        rete.close();
        file.close();

        return evidenceDBN;
    }

	//
	// START-BayesInference
	public CategoricalDistribution ask(final RandomVariable[] X,
									   final AssignmentProposition[] observedEvidence,
									   final BayesianNetwork bn) {
		try {
			return this.eliminationAsk(X, observedEvidence, bn);
		} catch (IOException e){
			e.printStackTrace();
		}
		return null;
	}

    public CategoricalDistribution eliminationAsk(final RandomVariable[] X,
                                                  final AssignmentProposition[] e, final BayesianNetwork bn) throws IOException {
        return null;
    }
}
